/**
 * Created by 土豆烧排骨
 * 2022/1/18 下午 11:28
 */


package com.survey.common;

public class TypeUtils {
    //将字符串类型转换成int类型
    public static int toInt(String str){
     return  Integer.parseInt(str);
    }
}
