/**
 * Created by 土豆烧排骨
 * 2022/1/18 下午 11:14
 */


package com.survey.service;

import com.survey.entity.FirstTitle;
import com.survey.entity.SecendTitle;

import java.util.List;

public interface SecendTitleService {
    List<SecendTitle> listSecendTitle(Integer fid);
}
