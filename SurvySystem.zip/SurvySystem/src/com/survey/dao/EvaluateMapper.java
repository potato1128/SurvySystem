package com.survey.dao;

public interface EvaluateMapper {

}
